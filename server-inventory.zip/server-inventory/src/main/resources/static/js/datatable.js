$(document).ready( function () {

	 Table = $("#serverInventorySearch").DataTable({
     data:[],
     columns: [
     { "data": "applicationName" },
     { "data": "serverName" },
     { "data": "regionName" }
     ],
     rowCallback: function (row, data) {},
     filter: false,
     info: false,
     ordering: false,
     processing: true,
     retrieve: true
     });

	 $("#searchButton").on("click", function (event) {
	 var applicationName = $("#appName").val();
	 var serverName = $("#serverName").val();
	 var regionName = $("#regionName").val();
	 var data = 'applicationName='
                         + encodeURIComponent(applicationName);
     $.ajax({
     url: "/search",
     type: "get",
     data: data
     }).done(function (result) {
     Table.clear().draw();
     Table.rows.add(result).draw();
     }).fail(function (jqXHR, textStatus, errorThrown) {
     // needs to implement if it fails
     });
     }
     );
});