package com.qbe.applications.controller;

import com.qbe.applications.entity.ServerInventory;
import com.qbe.applications.repository.ServerInventoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.List;

@RestController
public class ServerInventoryRestController {

    @Autowired
    private ServerInventoryRepository serverInventoryRepository;

    @GetMapping(path = "/search")
    public List<ServerInventory> getServerInventory(@RequestParam("applicationName") String applicationName) {

        return serverInventoryRepository.findByApplicationName(applicationName);
    }
}
