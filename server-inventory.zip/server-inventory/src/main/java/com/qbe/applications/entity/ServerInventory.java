package com.qbe.applications.entity;

import javax.persistence.*;

@Entity
@Table(name = "SERVERINVENTORY")
public class ServerInventory {

    @Id
    @GeneratedValue
    @Column(name="SERVER_INVENTORY_ID")
    private long id;

    @Column(name="APPLICATION_NAME")
    private String applicationName;

    @Column(name="SERVER_NAME")
    private String serverName;

    @Column(name="REGION_NAME")
    private String regionName;

    public ServerInventory() {
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getApplicationName() {
        return applicationName;
    }

    public void setApplicationName(String applicationName) {
        this.applicationName = applicationName;
    }

    public String getServerName() {
        return serverName;
    }

    public void setServerName(String serverName) {
        this.serverName = serverName;
    }

    public String getRegionName() {
        return regionName;
    }

    public void setRegionName(String regionName) {
        this.regionName = regionName;
    }
}
